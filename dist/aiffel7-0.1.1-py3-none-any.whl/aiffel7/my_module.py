# my_module.py

def greet(name):
    """ 사용자에게 인사말을 출력하는 함수 """
    return f"Hello, {name}!"

def add(a, b):
    """ 두 숫자의 합을 반환하는 함수 """
    return a + b
